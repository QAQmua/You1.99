import UIKit

// 📄 高性能 UIImage 内存位图缓存 (苹果底层 O(1) 瞬时映射)
final class ImageBitmapCache {
    static let shared = ImageBitmapCache()
    private let cache = NSCache<NSData, UIImage>()
    
    private init() {
        cache.countLimit = 150
        cache.totalCostLimit = 1024 * 1024 * 200 // 200MB 最大缓存
    }
    
    func image(from data: Data?) -> UIImage? {
        guard let data = data, !data.isEmpty else { return nil }
        let key = data as NSData
        if let cached = cache.object(forKey: key) {
            return cached
        }
        if let decoded = UIImage(data: data) {
            cache.setObject(decoded, forKey: key, cost: data.count)
            return decoded
        }
        return nil
    }
    
    func remove(for data: Data?) {
        guard let data = data, !data.isEmpty else { return }
        cache.removeObject(forKey: data as NSData)
    }
}
